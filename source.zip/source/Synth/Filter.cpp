#include "Filter.h"

Filter::Filter()
{
    filter.setType(juce::dsp::StateVariableTPTFilter<float>::Type::lowpass);
    filter.setCutoffFrequency(20000.0f);
    filter.setResonance(0.707f);
}

void Filter::setCutoff(float c)
{
    cutoff = juce::jlimit(20.0f, 20000.0f, c);
    filter.setCutoffFrequency(cutoff);
}

void Filter::setResonance(float r)
{
    resonance = juce::jlimit(0.1f, 10.0f, r);
    filter.setResonance(resonance);
}

void Filter::setSampleRate(float sr)
{
    sampleRate = (sr > 0.0f && sr <= 1000000.0f) ? sr : 44100.0f;
    juce::dsp::ProcessSpec spec;
    spec.sampleRate = static_cast<double>(sampleRate);
    spec.maximumBlockSize = 512;
    spec.numChannels = 1;
    filter.prepare(spec);
    filter.setCutoffFrequency(cutoff);
    filter.setResonance(resonance);
    filter.reset();
}

float Filter::process(float input)
{
    return filter.processSample(0, input);
}

void Filter::reset()
{
    filter.reset();
}